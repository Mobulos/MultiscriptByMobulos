registerPlugin({
    name: "Client Status in Channel Name",
    version: "0.4",
    description: "Shows status of a specified client in a specified channel name",
    author: "DrWarpMan <drwarpman@gmail.com>",
    backends: ["ts3"],
    engine: ">= 1.0",
    autorun: false,
    enableWeb: false,
    hidden: false,
    requiredModules: [],
    vars: [{
        name: "clientStatusInChannelNameList",
        type: "array",
        title: "Configuration:",
        vars: [{
                name: "channelID",
                type: "string",
                title: "Channel ID:",
                placeholder: "69"
            },
            {
                name: "clientUID",
                type: "string",
                title: "Client UID:",
                placeholder: "/Yst8oyDYEMkdNqR+zHRpXllbgA="
            },
            {
                name: "channelName",
                type: "string",
                title: "Channel name [Placeholder: %status%, %symbol%]:",
                placeholder: "%symbol% Owner [%status%]"
            },
            {
                name: "channelDescription",
                type: "multiline",
                title: "Channel description [Placeholder: %status%, %symbol%]:",
                placeholder: "%symbol% Owner [%status%]"
            },
            {
                name: "blockHide",
                type: "checkbox",
                title: "Check this box, to block this client from using hide command"
            },
            {
                name: "showType",
                type: "select",
                title: "Show in:",
                options: ["Channel name", "Channel name & description", "Channel description"]
            }
        ]
    }, {
        name: "textOnline",
        type: "string",
        title: "Online text (%status%):",
        placeholder: "ONLINE",
        default: "ONLINE"
    }, {
        name: "textOffline",
        type: "string",
        title: "Offline text (%status%):",
        placeholder: "OFFLINE",
        default: "OFFLINE"
    }, {
        name: "textAway",
        type: "string",
        title: "Away text (%status%):",
        placeholder: "AWAY",
        default: "AWAY"
    }, {
        name: "symbolOnline",
        type: "string",
        title: "Online symbol (%symbol%):",
        placeholder: "✅",
        default: "✅"
    }, {
        name: "symbolOffline",
        type: "string",
        title: "Offline symbol (%symbol%):",
        placeholder: "❌",
        default: "❌"
    }, {
        name: "symbolAway",
        type: "string",
        title: "Away symbol (%symbol%):",
        placeholder: "💼",
        default: "💼"
    }, {
        name: "commandToggleHide",
        type: "string",
        title: "Command to make yourself hidden (bot will think, that you are offline):",
        placeholder: "!togglehide",
        default: "!togglehide"
    }, {
        name: "awayEnabled",
        title: "Whether to use away text when AFK, or offline text when AFK? [CHECK to use away text when AFK]",
        type: "checkbox"
    }, {
        name: "awayChannels",
        title: "Channels (IDs), that if client is in, he is considered as AWAY",
        type: "strings"
    }, {
        name: "showTranslation",
        title: "Show translation?",
        type: "checkbox"
    }, {
        name: "messageHidden",
        type: "string",
        title: "MESSAGE: You are now hidden!",
        default: "You are now hidden!",
        placeholder: "Translate this message here!",
        conditions: [{
            field: "showTranslation",
            value: 1,
        }]
    }, {
        name: "messageNotHidden",
        type: "string",
        title: "MESSAGE: You are not hidden anymore!",
        default: "You are not hidden anymore!",
        placeholder: "Translate this message here!",
        conditions: [{
            field: "showTranslation",
            value: 1,
        }]
    }, {
        name: "messageNoRights",
        type: "string",
        title: "(To disable this message, write DISABLED) MESSAGE: You do not have permission to hide yourself!",
        default: "You do not have permission to hide yourself!",
        placeholder: "Translate this message here!",
        conditions: [{
            field: "showTranslation",
            value: 1,
        }]
    }],
    voiceCommands: []
}, (_, config, { name, version, author }) => {

    const backend = require("backend");
    const engine = require("engine");
    const store = require("store");
    const event = require("event");

    if (!config.symbolOnline) {
        config.symbolOnline = "✅";
        engine.log("Your online symbol is undefined, using default one!");
    }

    if (!config.symbolOffline) {
        config.symbolOffline = "❌";
        engine.log("Your offline symbol is undefined, using default one!");
    }

    if (!config.symbolAway) {
        config.symbolAway = "💼";
        engine.log("Your away symbol is undefined, using default one!");
    }

    let blockHideList = {};

    config.clientStatusInChannelNameList.forEach(i => {
        let blockHide = i.blockHide;
        let clientUID = i.clientUID;
        blockHideList[clientUID] = blockHide;
    });

    event.on("chat", chatInfo => {
        let message = chatInfo.text.toLowerCase();
        let client = chatInfo.client;
        let clientUID = client.uid();

        if (message.startsWith(config.commandToggleHide.toLowerCase())) {
            let data = store.get(clientUID);
            let blockHide = blockHideList[clientUID];

            if (!blockHide) {
                if (!data) {
                    store.set(clientUID, { hidden: true });
                    client.chat(config.messageHidden);
                } else if (data.hidden === false) {
                    store.set(clientUID, { hidden: true });
                    client.chat(config.messageHidden);
                } else if (data.hidden === true) {
                    store.set(clientUID, { hidden: false });
                    client.chat(config.messageNotHidden);
                }
                return;
            } else if (blockHide) {
                if (config.messageNoRights.toLowerCase() !== "disabled")
                    client.chat(config.messageNoRights);
            }
        }
    });

    setInterval(() => {
        if (backend.isConnected()) {
            config.clientStatusInChannelNameList.forEach(i => {
                let channelID = i.channelID;
                let clientUID = i.clientUID;
                let channelName = i.channelName;
                let channelDescription = i.channelDescription;
                let blockHide = i.blockHide;
                let showType = i.showType;

                let channel = backend.getChannelByID(channelID);

                if (channel) {
                    let client = backend.getClientByUID(clientUID);

                    if (!blockHide && client) {
                        let clientData = store.get(client.uid());

                        if (clientData !== undefined)
                            if (clientData.hidden === true)
                                client = undefined;
                    }

                    let clientAFK = (client && config.awayEnabled) ? (client.isAway() || checkArrays(client.getChannels().map(ch => ch.id()), config.awayChannels)) : false;

                    let status = (client) ? ((clientAFK) ? config.textAway : config.textOnline) : config.textOffline;
                    let symbol = (client) ? ((clientAFK) ? config.symbolAway : config.symbolOnline) : config.symbolOffline;

                    if (showType != 2 && channelName) {
                        let name = channelName.replace("%status%", status).replace("%symbol%", symbol);
                        channel.setName(name);
                    }
                    if (showType && showType != 0 && channelDescription) {
                        let desc = channelDescription.replace("%status%", status).replace("%symbol%", symbol);
                        channel.setDescription(desc);
                    }
                }
            });
        }
    }, 30 * 1000);

    /**
     * Checking if two arrays have at least one same item
     * @param  {array} arr1 First array
     * @param  {array} arr2 Second array
     * @return {boolean}      Whether they have / don't have at least one same item
     */
    function checkArrays(arr1, arr2) {
        if (arr1 === arr2)
            return true;

        if (arr1 === undefined || arr2 === undefined)
            return false;

        return arr2.some(item => arr1.includes(item));
    }

    // SCRIPT LOADED SUCCCESFULLY
    engine.log(`\n[Script] "${name}" [Version] "${version}" [Author] "${author}"`);
});