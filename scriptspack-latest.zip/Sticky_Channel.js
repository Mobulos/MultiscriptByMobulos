registerPlugin({
    name: 'Sticky Channel',
    version: '2.1',
    description: 'You can bind the bot to a specified channel. The bot always goes back or if no users in the new channel.',
    author: 'TS3index.com <info@ts3index.com>',
    vars: {
        stickyMode: {
            title: 'Mode:',
            type: 'select',
            options: [
                'always goes back',
                'goes back if no users in the new channel'
            ]
        },
        channelId: {
            title: 'Channel:',
            type: 'channel',
            placeholder : 'Channel ID'
        },
        channelPw: {
            title: 'Channel-Password: (Optional)',
            type: 'password'
        }
    }
}, function(sinusbot, config) {
    var engine = require('engine');
    var backend = require('backend');
    var event = require('event');
    
    if (!config || typeof config.stickyMode == 'undefined' || typeof config.channelId == 'undefined'|| !config.channelId) {
        engine.log("Settings invalid.");
        return;
    }
    
    if (isNaN(config.channelId)) {
        if (engine.isRunning() && backend.isConnected()) {
            engine.log("No valid Channel ID, search Channel...");
            var channel = backend.getChannelByName(config.channelId);
            if (typeof channel == 'undefined' || channel.id() < 1) {
                engine.log("No Channel found, Settings invalid... Script not loaded.");
                return;
            } else {
                engine.log("Channel '" + channel.name() + "' with ID '" + channel.id() + "' found, Settings improved.");
                config.channelId = channel.id();
                engine.saveConfig(config);
            }
        } else {
            engine.log("No valid Channel ID and Instance is not running... Script not loaded.");
            return;
        }
    }

    if (typeof config.channelPw == 'undefined' || !config.channelPw) config.channelPw = " "; //FIX
    
    function moveBot() {
        if (engine.isRunning() && backend.isConnected()) {
            if (backend.getCurrentChannel().id() !== config.channelId) {
                if (backend.getBotClient().moveTo(config.channelId, config.channelPw)) return;
                engine.log("Move-error, no permissions? You can find the problem in 'TS/ERR' entrys.");
            }
        }
    }
    
    event.on('clientMove', function(ev) {
        if (!backend.isConnected() || typeof ev.fromChannel == 'undefined') return;
        
        var currentChannel = backend.getCurrentChannel();
        if (currentChannel.id() !== config.channelId) {
            if (config.stickyMode == 1) {
                if (currentChannel.getClientCount() <= 1) moveBot();
            } else {
                if (ev.client.isSelf()) moveBot();
            }
        }
    });
    
    moveBot();
});
