registerPlugin({
    name: 'SaveCPU (Alone mode)',
    version: '1.3',
    description: 'This script will save CPU and bandwidth by stopping or muting the bot when nobody in bot channel, also bot can set the sound volume to the value you specify, when someone comes to the bot channel after it was alone. In the "stop playback" mode there is a function resume playback track from playlist, if played track from playlist when bot it was stopped, also resume playback from "Youtube", from simple stream url and from build-in radiostation list of "Sinusbot". IMPORTANT!!! In the "stop playback" mode default track must be assigned! Also, resume playback is disabled by default!',
    author: 'kapabac',
    vars: [{
        name: 'mode',
        title: 'Mode',
        type: 'select',
        options: [
            'stop playback',
            'mute only'
        ]
    }, {
        name: 'defaultTrack',
        title: 'Default track',
        indent: 1,
        type: 'track',
        conditions: [{
            field: 'mode',
            value: 0
        }]
    }, {
        name: 'resumePlayback',
        title: 'Resume playback when someone comes to the bot channel after it was alone (only for "stop playback" mode)',
        indent: 1,
        type: 'checkbox',
        conditions: [{
            field: 'mode',
            value: 0
        }]
    }, {
        name: 'useDefaultTrack',
        title: 'Always play the default track when someone comes to the bot channel after it was alone (only for "stop playback" mode)',
        indent: 2,
        type: 'checkbox',
        conditions: [{
            field: 'mode',
            value: 0
        }, {
            field: 'resumePlayback',
            value: true
        }]
    }, {
        name: 'useDefaultVolume',
        title: 'The volume value that will be set each time someone comes to the bot channel after it was alone',
        type: 'checkbox',
    }, {
        name: 'defaultVolume',
        title: 'Default volume value (0-100)',
        indent: 1,
        type: 'number',
        placeholder: 'default: 10',
        conditions: [{
            field: 'useDefaultVolume',
            value: true
        }]
    }]
}, function (_, config) {
    var lastTrack = {
            'beforeLast': {}
        },
        timeOut = false,
        event = require('event'),
        audio = require('audio'),
        media = require('media'),
        store = require('store'),
        backend = require('backend');

    if (config.useDefaultVolume) var defaultVolume = (!config.defaultVolume || config.defaultVolume > 100 || config.defaultVolume < 0) ? 10 : config.defaultVolume;
    if (typeof config.mode == 'undefined') config.mode = 1;
    if (config.mode == 0) {
        if (config.defaultTrack) {
            defaultTrack = config.defaultTrack;
        } else return;
        if (audio.isMute()) audio.setMute(false);
        if (typeof config.resumePlayback == 'undefined') config.resumePlayback = false;
        if (store.getInstance('lastTrack')) {
            lastTrack = store.getInstance('lastTrack');
        } else {
            lastTrack.stopped = false;
            getLastTrack();
        }
    }

    setInterval(function () {
        if (backend.isConnected() && !timeOut) checkAlone();
    }, 60000);

    event.on('clientMove', function (ev) {
        if ((ev.toChannel != null && ev.toChannel.id() == backend.getCurrentChannel().id()) || (ev.fromChannel != null && ev.fromChannel.id() == backend.getCurrentChannel().id())) checkAlone();
    });

    if (config.mode == 0) {
        event.on('trackEnd', function () {
            if (lastTrack.stopped) {
                lastTrack.stopped = false;
                return;
            }
            timeOut = true;
            lastTrack.position = 0;
            setTimeout(function () {
                checkAlone();
                timeOut = false;
            }, 10000);
        });
    }

    function checkAlone() {
        if (backend.getCurrentChannel().getClientCount() > 1) {
            if (config.mode == 1) {
                if (audio.isMute()) {
                    if (config.useDefaultVolume) audio.setVolume(defaultVolume);
                    audio.setMute(false);
                }
                return;
            }
            if (lastTrack.id != media.getCurrentTrack().id() || lastTrack.url != media.getCurrentTrack().url()) getLastTrack();
            if (!audio.isPlaying() && config.resumePlayback) {
                if (config.useDefaultVolume) audio.setVolume(defaultVolume);
                if (config.useDefaultTrack) {
                    media.getTrackByID(defaultTrack.url.split('/')[2]).play();
                    return;
                }
                if (lastTrack.playlistId) media.getPlaylistByID(lastTrack.playlistId).setActive();
                if (lastTrack.id != '') {
                    media.getTrackByID(lastTrack.id).play();
                    audio.seek(lastTrack.position);
                } else if (lastTrack.type == 'url') {
                    media.playURL(lastTrack.url);
                } else if (lastTrack.type == 'ytdl' && lastTrack.url != '' && lastTrack.url.indexOf('ytdl://ytdl/?url=') == 0) {
                    if (lastTrack.ytUrl == lastTrack.url) {
                        beforeLast();
                        getLastTrack();
                        return;
                    }
                    var ytUrl = decodeURIComponent(lastTrack.url.substring(17).split('&')[0]);
                    ytUrl = ytUrl.length == 11 ? ('https://www.youtube.com/watch?v=' + ytUrl) : ytUrl;
                    lastTrack.beforeLast.url = lastTrack.url;
                    lastTrack.ytUrl = lastTrack.url;
                    media.yt(ytUrl);
                } else beforeLast();
            }
            if (config.mode == 0) getLastTrack();
        } else if (config.mode == 1) {
            if (!audio.isMute()) audio.setMute(true);
        } else if (audio.isPlaying()) {
            lastTrack.stopped = true;
            getLastTrack();
            media.stop();
        }
    }

    function beforeLast() {
        if (lastTrack.beforeLast.playlistId) {
            media.getPlaylistByID(lastTrack.beforeLast.playlistId).setActive();
        }
        if (lastTrack.beforeLast.id == '' && lastTrack.beforeLast.url == '') {
            media.getTrackByID(defaultTrack.url.split('/')[2]).play();
            return;
        }
        if (lastTrack.beforeLast.id != '') {
            media.getTrackByID(lastTrack.beforeLast.id).play();
            return;
        }
        if (lastTrack.beforeLast.url != '') {
            if (lastTrack.beforeLast.url.indexOf('ytdl://ytdl/?url=') == 0) {
                if (lastTrack.ytUrl != lastTrack.url) {
                    var ytUrl = decodeURIComponent(lastTrack.beforeLast.url.substring(17).split('&')[0]);
                    ytUrl = ytUrl.length == 11 ? ('https://www.youtube.com/watch?v=' + ytUrl) : ytUrl;
                    media.yt(ytUrl);
                } else media.getTrackByID(defaultTrack.url.split('/')[2]).play();
            } else media.playURL(lastTrack.beforeLast.url);
            return;
        }
        media.getTrackByID(defaultTrack.url.split('/')[2]).play();
    }

    function getLastTrack() {
        lastTrack.position = audio.getTrackPosition();
        lastTrack.id = media.getCurrentTrack().id();
        lastTrack.url = media.getCurrentTrack().url();
        lastTrack.type = media.getCurrentTrack().type();
        lastTrack.title = media.getCurrentTrack().title();
        if (media.getActivePlaylist()) {
            lastTrack.playlistId = media.getActivePlaylist().id();
        } else lastTrack.playlistId = false;
        if (lastTrack.id != '' || (lastTrack.type == 'ytdl' && lastTrack.url != '')) {
            if (lastTrack.playlistId) {
                lastTrack.beforeLast.playlistId = lastTrack.playlistId;
            } else lastTrack.beforeLast.playlistId = false;
            lastTrack.beforeLast.id = lastTrack.id;
            lastTrack.beforeLast.url = lastTrack.url;
        }
        store.setInstance('lastTrack', lastTrack);
    }
});