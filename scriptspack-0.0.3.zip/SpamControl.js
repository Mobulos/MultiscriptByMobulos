registerPlugin ({
	name: 'SpamControl',
	version: '1.4',
	description: 'Warn, kick or ban clients that switch channels or change nicknames to often.',
	author: 'Rick Wolthuis <rick@rwolthuis.nl>',
	backends: ['ts3'],
	enableWeb: true
}, function (bot, conf)
{
	/* Require modules. */
	var engine	= require ('engine');
	var event	= require ('event');
	var backend	= require ('backend');
	var store	= require ('store');
	
	/* Object to save client information. */
	var client_info = {};
	
	/* Define if the configuration is loaded or not. */
	var conf_loaded = false;
	
	/* Redefine the conf var with an empty object. */
	conf = {};
	
	
	/* Function to load configuration. */
	function load_configuration (cb)
	{
		/* Retrieve all configuration of the current instance. */
		var config = store.getAllInstance ();
		
			/* Is there more then one setting saved? */
			if (Object.keys (config).length > 0)
			{
				/* Yes, loop through the configuration` of this instance. */
				for (var name in config)
				{
					/* Save the configuration item in the conf object. */
					conf[name] = config[name];
				}
			}
			else
			{
				/* No, instance is not configured yet. Log this message. */
				engine.log ('SpamControl is not yet configured for this instance causing all features to be disabled by default. Open the web interface of the SpamControl script, select the instance and configure the script as desired..');
			}
			
			/* Is cb a function? */
			if (typeof cb == 'function')
			{
				/* Yes, call the callback. */
				cb ();
			}
	}
	
	
	/* Function to kick a client. */
	function kick (client_id, msg) 
	{
		/* Retrieve the client object by using the client ID. */
		var client = backend.getClientByID (client_id);
		
			/* Is the client known by the backend? */
			if (typeof client != 'undefined')
			{
				/* Yes, kick the client, with the message provided (if available). */
				client.kick ((typeof msg != 'undefined') ? msg : '');
				
				/* Log. */
				engine.log ('Client with ID \'' + client_id + '\' was kicked.');
			}
	}
	
	
	/* Function to ban a client. */
	function ban (client_id, ban_time, msg)
	{
		/* Retrieve the client object by using the client ID. */
		var client = backend.getClientByID (client_id);
		
			/* Is the client known by the backend? */
			if (typeof client != 'undefined')
			{
				/* Ban the client for the given time, with the message provided (if available). */
				client.ban (ban_time, (typeof msg != 'undefined') ? msg : '');
				
				/* Log. */
				engine.log ('Client with ID \'' + client_id + '\' was ' + ((ban_time == 0) ? 'permanently banned.' : 'banned for \'' + ban_time + '\' seconds.'));
			}
	}
	
	
	/* Function to send a warning to a client. */
	function warn (client_id, type, msg)
	{
		/* Retrieve the client object by using the client ID. */
		var client = backend.getClientByID (client_id);
		
			/* Is the client known by the backend, and is type either 'chat' or 'poke'? */
			if (typeof client != 'undefined' && (type == 'priv' || type == 'poke'))
			{
				/* Yes, is type priv? */
				if (type == 'priv')
				{
					/* Yes, change to chat (funciton name of private chat). */
					type = 'chat';
				}
				
				/* Yes, send the message through the selected media. */
				client[type](msg);
				
				/* Log. */
				engine.log ('Client with ID \'' + client_id + '\' received a warning (' + msg + ').');
			}
	}
	
	
	/* Function to check if a client is in the provided servergroup or not. */
	function is_in_server_group (client, servergroup_array)
	{
		/* Retrieve all servergroups the client is member of. */
		var client_servergroups = client.getServerGroups ();
		
			/* Loop through the servergroup_array array. */
			for (var i in servergroup_array)
			{
				/* Loop through the servergroups the client is member of. */
				for (var j in client_servergroups)
				{
					/* Are the group ID's equal? */
					if (parseInt (servergroup_array[i]) == client_servergroups[j].id ())
					{
						/* Yes, client is within one of the provided servergroups. Return true. */
						return true;
					}
				}
			}
		
		/* Client is not in one of the provided servergroups. Return false. */
		return false;
	}
	
	
	/* Function to add an client to the client_info object, or add a event to it's object. */
	function add_to_client (client_id, type)
	{
		/* Is the client_id the same ID of the bot itself? */
		if (backend.getBotClientID () != client_id)
		{
			/* No, does info of the client exists? */
			if (client_id in client_info)
			{
				/* Yes, does the type exists as key in the client object? */
				if (type in client_info[client_id] && type != 'timeout')
				{
					/* Yes, add +1 on the type. */
					client_info[client_id][type]++;
				}
			}
			else
			{
				/* No, define the timeout seconds first. */
				var timeout_sec = ('general_settings' in conf && 'interval' in conf.general_settings) ? conf.general_settings.interval : 10;
				
				/* Create an object. */
				client_info[client_id] = {
					channel_switching: (type == 'channel_switching') ? 1 : 0,
					channel_creating: (type == 'channel_creating') ? 1 : 0,					
					nickname_changing: (type == 'nickname_changing') ? 1 : 0,
					timeout: setTimeout (function ()
					{
						/* Call the check_client function. */
						check_client (client_id);
					}, (parseInt (timeout_sec) * 1000))
				};
			}
		}
	}
	
	
	/* Function that is executed when the timeout fires for a client check event. */
	function check_client (client_id)
	{
		/* Is channel_switching present in conf? */
		if ('channel_switching' in conf)
		{
			/* Yes, did the client exceed the ban limit? */
			if (conf.channel_switching.ban_enabled && conf.channel_switching.ban_enabled == 'true' && client_info[client_id].channel_switching >= parseInt (conf.channel_switching.ban_actions))
			{
				/* Ban the client. */
				ban (client_id, parseInt (conf.channel_switching.ban_time), conf.channel_switching.ban_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick limit? */
			if (conf.channel_switching.kick_enabled && conf.channel_switching.kick_enabled == 'true' && client_info[client_id].channel_switching >= parseInt (conf.channel_switching.kick_actions))
			{
				/* Kick the client. */
				kick (client_id, conf.channel_switching.kick_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick warning? */
			if (conf.channel_switching.warning_enable && conf.channel_switching.warning_enable== 'true' && client_info[client_id].channel_switching >= parseInt (conf.channel_switching.warning_actions))
			{
				/* Define the warning type. */
				var warning_type = (conf.channel_switching.warning_type == 'poke' || conf.channel_switching.warning_type == 'priv') ? conf.channel_switching.warning_type : 'poke';
				
				/* Send warning. */
				warn (client_id, warning_type, conf.channel_switching.warning_message);
			}
		}
		
		
		/* Is channel_creating present in conf? */
		if ('channel_creating' in conf)
		{
			/* Yes, did the client exceed the ban limit? */
			if (conf.channel_creating.ban_enabled && conf.channel_creating.ban_enabled == 'true' && client_info[client_id].channel_creating >= parseInt (conf.channel_creating.ban_actions))
			{
				/* Ban the client. */
				ban (client_id, parseInt (conf.channel_creating.ban_time), conf.channel_creating.ban_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick limit? */
			if (conf.channel_creating.kick_enabled && conf.channel_creating.kick_enabled == 'true' && client_info[client_id].channel_creating >= parseInt (conf.channel_creating.kick_actions))
			{
				/* Kick the client. */
				kick (client_id, conf.channel_creating.kick_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick warning? */
			if (conf.channel_creating.warning_enable && conf.channel_creating.warning_enable == 'true' && client_info[client_id].channel_creating >= parseInt (conf.channel_creating.warning_actions))
			{
				/* Define the warning type. */
				var warning_type = (conf.channel_creating.warning_type == 'poke' || conf.channel_creating.warning_type == 'priv') ? conf.channel_creating.warning_type : 'poke';
				
				/* Send warning. */
				warn (client_id, warning_type, conf.channel_creating.warning_message);
			}
		}
		
		
		/* Is nickname_changing present in conf? */
		if ('nickname_changing' in conf)
		{
			/* Yes, did the client exceed the ban limit? */
			if (conf.nickname_changing.ban_enabled && conf.nickname_changing.ban_enabled == 'true' && client_info[client_id].nickname_changing >= parseInt (conf.nickname_changing.ban_actions))
			{
				/* Ban the client. */
				ban (client_id, parseInt (conf.nickname_changing.ban_time), conf.nickname_changing.ban_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick limit? */
			if (conf.nickname_changing.kick_enabled && conf.nickname_changing.kick_enabled == 'true' && client_info[client_id].nickname_changing >= parseInt (conf.nickname_changing.kick_actions))
			{
				/* Kick the client. */
				kick (client_id, conf.nickname_changing.kick_message);
				
				/* Return so the function doesn't continue. */
				return;
			}
			else
			/* No, does the client exceed the kick warning? */
			if (conf.nickname_changing.warning_enable && conf.nickname_changing.warning_enable == 'true' && client_info[client_id].nickname_changing >= parseInt (conf.nickname_changing.warning_actions))
			{
				/* Define the warning type. */
				var warning_type = (conf.nickname_changing.warning_type == 'poke' || conf.nickname_changing.warning_type == 'priv') ? conf.nickname_changing.warning_type : 'poke';
				
				/* Send warning. */
				warn (client_id, warning_type, conf.nickname_changing.warning_message);
			}
		}
		
		/* Delete the client object. */
		delete client_info[client_id];
	}
	
	
	/* Function executed when a client moves. */
	function on_client_move (ev)
	{
		/* Is this client not the bot, and is this client in one of the server groups that should be ignored? */
		if (!ev.client.isSelf () && !is_in_server_group (ev.client, conf.channel_switching.ignore_servergroup))
		{
			/* Because this config has been added in an update, it might not exist in bots that already installed a previous version. Use 'true' as default value if the configuration is missing. */
			conf.channel_switching.invoker_check = conf.channel_switching.invoker_check | 'true';
			
				/* Is the invoker check inactive, or is it active and did the client invoked the action himself? */
				if (conf.channel_switching.invoker_check != 'true' || (conf.channel_switching.invoker_check == 'true' && ev.invoker == null))
				{
					/* Yes, get the client ID. */
					var client_id = ev.client.id ();
					
						/* Did the client disconnect or became invisible? */
						if (ev.toChannel != null)
						{
							/* No, client is still connected and visible. Count the event. */
							add_to_client (client_id, 'channel_switching');
						}
						else
						{
							/* Yes, the client disconnected or became invisible. Does the client still exists in the client_info object? */
							if (typeof client_info[client_id] != 'undefined')
							{
								/* Yes, clear any running timeouts. */
								clearTimeout (client_info[client_id].timeout);
								
								/* Delete the client from the client_info object. */
								delete client_info[client_id];
							}
						}
				}
		}
	}
	
	
	/* Function executes when a client renames itself. */
	function on_client_rename (client)
	{
		/* Is this client not the bot itself, or should this client be ignored? */
		if (!client.isSelf () && !is_in_server_group (client, conf.nickname_changing.ignore_servergroup))
		{
			/* No, add event to client. */
			add_to_client (client.id (), 'nickname_changing');
		}
	}
	
	
	/* FUnction executed when a client creates a temp. channel. */
	function on_channel_create (client)
	{
		/* Is this client not the bot itself, or should this client be ignored? */
		if (!client.isSelf () && !is_in_server_group (client, conf.channel_creating.ignore_servergroup))
		{
			/* No, add event to client. */
			add_to_client (client.id (), 'channel_creating');
		}
	}
	
	
	
	/* API event to retrieve all server groups. */
	event.on ('api:getServerGroups', function (ev)
	{
		/* Retrieve all server groups. */
		var groups = backend.getServerGroups ();
		
		/* Create a data object. */
		var data = {};
		
			/* Loop through all groups. */
			for (var i in groups)
			{
				/* Place the name of the group in the data object under the servergroup id as key. */
				data[groups[i].id ()] = groups[i].name ();
			}
		
		/* Return the data object. */
		return {data: data};
	});
	
	
	/* API event to return the stored configuration of the current instance. */
	event.on ('api:get_instance_config', function (ev)
	{
		/* Return the conf object. */
		return {config: conf};
	});
	
	
	/* API event to save new config. */
	event.on ('api:set_instance_config', function (ev)
	{
		/* Get the data from the API call. */
		var data = ev.data ();
		
		/* Retrieve the keys of the data object. */
		var keys = Object.keys (data);
		
			/* Are there keys in the first place? */
			if (keys.length > 0)
			{
				/* Yes, there are. Loop through them. */
				for (var i in keys)
				{
					/* Get the API data from the key, and 'store' it in this instance. */
					store.setInstance (keys[i], data[keys[i]]);
				}
				
				/* Reload the config. */
				load_configuration (function ()
				{
					/* Log. */
					engine.log ('New configuration was saved.');
				});
			}
	});
	
	
	/* When a client moves. */
	event.on ('clientMove', function (ev)
	{
		/* Is the configuration loaded, and is the channel_switching feature enabled? */
		if (conf_loaded === true && 'channel_switching' in conf && 'enabled' in conf.channel_switching && conf.channel_switching.enabled == 'true')
		{
			/* Yes, execute on_client_move function. */
			on_client_move (ev);
		}
	});
	
	
	/* When a client renames itself. */
	event.on ('clientNick', function (client, old_nick)
	{
		/* Is the configuration loaded? */
		if (conf_loaded === true && 'nickname_changing' in conf && 'enabled' in conf.nickname_changing && conf.nickname_changing.enabled == 'true')
		{
			/* Yes, execute on_client_rename function. */
			on_client_rename (client);
		}
	});
	
	
	/* When a client creates a channel. */
	event.on ('channelCreate', function (channel, invoker)
	{
		/* Is the created channel a temp. channel? */
		if (!channel.isPermanent () && !channel.isSemiPermanent ())
		{
			/* Yes, is the configuration loaded? */
			if (conf_loaded === true && 'channel_creating' in conf && 'enabled' in conf.channel_creating && conf.channel_creating.enabled == 'true')
			{
				/* Yes, execute on_channel_create function. */
				on_channel_create (invoker);
			}
		}
	});
	
	
	/* Load the configuration. */
	load_configuration (function ()
	{
		/* Configuration is now loaded. Set conf_loaded to true so monitoring will start. */
		conf_loaded = true;
	});
});