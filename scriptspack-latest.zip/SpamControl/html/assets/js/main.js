/* 
	SpamControl v1.3 script for SinusBot.
	Developed by Rick Wolthuis (rick@rwolthuis.nl).
	URL to resource: https://forum.sinusbot.com/resources/spamcontrol.319/
	
	License:
		You can edit the script in anyway you like. When reposting an edited script as resource, please let me know and refere to the original resource URL.
*/


/* Place for the selected instance. */
var instance = null;

/* Place for all instances. */
var instance_list = [];

/* Place for selected instance configuration. */
var instance_config = null;

/* Place for the current page. */
var current_page = null;

/* Place for the saving timeout timeout. */
var saving_timeout = null;

/* Place for the server group object. */
var server_groups = {};



/* Function to select a new instance. */
function select_instance (uuid)
{
	/* Does the instance exists? */
	if (uuid in instance_list)
	{
		/* Yes, load the configuration of the new instance. */
		get_instance_config (uuid, function ()
		{
			/* Instance config is loaded. Set the current instance to the newly one. */
			instance = uuid;
			
				/* Is the current_page null? */
				if (current_page != null)
				{
					/* No, meaning that there is a page selected. Reload this page. */
					load_page (current_page);
				}
		});
	}
}


/* Function to the configuration of the selected instance. */
function get_instance_config (uuid, cb)
{
	/* Request the configuration of a specific instance. */
	$.post ('/api/v1/bot/i/' + uuid + '/event/get_instance_config', function (data)
	{
		/* Is data null? */
		if (data == null)
		{
			/* Yes, send an alert message. */
			alert ('It appears that the selected instance does not have the SpamControl script enabled. Please enable the script by checking the checkbox in the Scripts menu while having the instance selected.');
			
			/* Return, so we dont continue any further. */
			return;
		}
		
		/* Save the instance config data. */
		instance_config = data[0].config;
		
		/* Request the configuration of a specific instance. */
		$.post ('/api/v1/bot/i/' + uuid + '/event/getServerGroups', function (data)
		{
			/* Save the servergroups. */
			server_groups = data[0].data;
			
			/* Run the callback function. */
			cb ();	
		});
	});
}


/* Function to save the configuration to the selected instance. */
function set_instance_config (uuid, cb)
{
	/* Send the current in memory stored confiuration object to the bot. */
	$.post ('/api/v1/bot/i/' + uuid + '/event/set_instance_config', JSON.stringify (instance_config), cb);
}


/* Function to retrieve all instances available. */
function load_all_instances ()
{
	/* Retrieve all instances through the API, and return the data to the callback function. */
	$.get ('/api/v1/bot/instances', function (data)
	{
		/* Are there any instances? */
		if (data.length > 0)
		{
			/* Yes, loop through the array of instances. */
			for (var i in data)
			{
				/* Save the instance data in the instance_list. */
				instance_list[data[i].uuid] = data[i];
				
				/* Define the instance name as the instance name, or the nickname if the instance name is empty. */
				data[i].instance_name = (data[i].name != '') ? data[i].name : data[i].nick;
				
				/* Add the instance to the select html object. */
				$('#instance_selector').append ($('<option></option>').attr ('value', data[i].uuid).text (data[i].instance_name));
				
				/* Rehook events. */
				hook_events ();
				
					/* Is an instance set in the localStorage, and a 36 char string? */
					if (window.localStorage.instanceId != undefined && window.localStorage.instanceId.length == 36)
					{
						/* Yes, select the instance for us. */
						$('#instance_selector').val (window.localStorage.instanceId).change ();
					}
			}
		}
		else
		{
			/* No, alert. */
			alert ('There are no instances in your SinusBot.');
		}
	});
}


/* Function to load a page. */
function load_page (item)
{
	/* Is the instance config set? */
	if (instance_config == null)
	{
		/* No, probably the selected instance does not have the script enabled. Alert this. */
		alert ('To configure the SpamControl configuration of an instance, first select an instance that has the SpamControl script enabled.');
		
		/* Return, so we dont switch pages. */
		return;
	}

	/* Perform a get request. */
	$.get ('./pages/' + $(item).attr ('href') + '.html', (data) =>
	{
		/* Is the current page the same as the item page? */
		if (current_page != item)
		{
			/* No, we've changed pages. Remove the 'active' class from the parent (li) of the current_page. */
			$(current_page).parent ().removeClass ('active');
			
			/* Add the 'active' class to the parent (li) of the new page. */
			$(item).parent ().addClass ('active');
		}
		
		/* Save the selected page as the current page. */
		current_page = item;
		
		/* Add the HTML to the page content. */
		$('#page_content').html (data);
		
			/* Is there an object with the same name as the page name, and does that object contains the init function? */
			if (typeof window[$(item).attr ('href')] != 'undefined' && typeof window[$(item).attr ('href')].init == 'function')
			{
				/* Hey, there is! Initialize it. */
				window[$(item).attr ('href')].init ();
			}
			
		/* Rehook events. */
		hook_events ();
	}).fail ((err) =>
	{
		/* Did we got a 404 (page doesn't exist) error? */
		if (err.status == 404)
		{
			/* Yes, send an alert to the user. */
			alert ('The requested page, does not exist.');
		}
		else
		{
			/* No, unknown error occured. Alert the message received. */
			alert (data.responseText);
		}
	});
}


/* Function to (re)hook events. */
function hook_events ()
{
	/* Hook event to the instance selector. */
	$('#instance_selector').unbind ('change').change (function ()
	{
		/* Does the selected instance exists? */
		if (this.value in instance_list)
		{
			/* Yes, it is. Load the configuration of this instance. */
			select_instance (this.value);
		}
	});
	
	
	/* When a servergroup is being added to a table. */
	$('.btn-servergroups-add').unbind ('click').click (function (e)
	{
		/* Prevent default click behevior. */
		e.preventDefault ();
		
		/* Define the parent. */
		var parent = $(this).parent ().parent ().parent ();
		
		/* Define the selected server group. */
		var selected_group = $(parent).find ('[name="servergroups"]').val ()
		
			/* Does the group exists? */
			if (selected_group in server_groups)
			{
				/* Yes, define exists. */
				var exists = false;
				
					/* Loop through all rows in the table. */
					$(parent).find ('.table-servergroups tbody tr').each (function (i)
					{
						/* Is the servergroup id the same as the selected one? */
						if ($(this).attr ('sgid') == selected_group)
						{
							/* Yes, change exists to true. */
							exists = true;
						}
					});
				
					/* Is exists still false? */
					if (exists == false)
					{
						/* Add the server group. */
						$(parent).find ('.table-servergroups > tbody:last-child').append ('<tr sgid="' + selected_group + '"><td>' + selected_group + '</td><td>' + server_groups[selected_group] + '</td><td><a href="#" class="btn btn-danger btn-xs btn-servergroups-remove">Remove group</a></td></tr>');
						
							/* Was there a no-rows message in the tabel? */
							if ($(parent).find ('.table-servergroups tbody td[colspan="3"]').length > 0)
							{
								/* Yes, delete it. */
								$(parent).find ('.table-servergroups tbody td[colspan="3"]').parent ().remove ();
							}						
						
						/* Rehook events. */
						hook_events ();
					}
			}
	});
	
	
	/* When a servergroup is being deleted. */
	$('.btn-servergroups-remove').unbind ('click').click (function (e)
	{
		/* Prevent default click behevior. */
		e.preventDefault ();
		
		/* Delete the row. */
		$(this).parent ().parent ().remove ();
		
			/* Was this the last row in the table? */
			if ($('.table-servergroups tbody tr').length == 0)
			{
				/* Yes, add the no-rows message. */
				$('.table-servergroups tbody').append ('<tr><td colspan="3" class="text-center">Currently no servergroups are being excluded.</td></tr>');		
			}
	});
}


/* Function to add default values for all missing configuration items. */
function insert_configuration (key)
{
	/* Is the provided key present in the configuration of this instance? */
	if (!(key in instance_config))
	{
		/* No, add it to the global configuration of this instance. */
		instance_config[key] = {};
	}
	
	/* Loop through all input fields on the page. */
	$('input').each (function (index)
	{
		/* Does this configuration item exists? */
		if (!($(this).attr ('name') in instance_config[key]))
		{
			/* No, add it to the configuration. */
			instance_config[key][$(this).attr ('name')] = $(this).attr ('default');
		}
	});
	
	/* Loop through all select fields on the page. */
	$('select:not(.exclude)').each (function (index)
	{
		/* Does this configuration item exists? */
		if (!($(this).attr ('name') in instance_config[key]))
		{
			/* No, add it to the configuration. */
			instance_config[key][$(this).attr ('name')] = $(this).attr ('default');
		}
	});
	
	/* Is there a servergroup table on the page? */
	if ($('.table-servergroups').length > 0)
	{
		/* Yes, is there a ignore_servergroup item in the configuration object? */
		if (!('ignore_servergroup' in instance_config[key]))
		{
			/* No, add the ignore_servergroup item as array to the config. */
			instance_config[key]['ignore_servergroup'] = [];
		}
	}
	
	/* Is there a 'servergroups' select object? */
	if ($('select[name="servergroups"]').length > 0)
	{
		/* Yes, loop through the server groups. */
		for (var i in server_groups)
		{
			/* Add an option to the select object. */
			$('select[name="servergroups"]').append ($('<option></option>').attr ('value', i).text (server_groups[i] + ' (' + i + ')'));
		}
	}
}


/* Function to load the configuration of this page into the page. */
function load_configuration (key)
{
	/* Loop through the provided key config. */
	for (var i in instance_config[key])
	{
		/* Is the key 'ignore_servergroup'? */
		if (i == 'ignore_servergroup')
		{
			/* It is. Continue, because we process this seperately. */
			continue;
		}
		
		/* Select the item. */
		var item = $('[name="' + i + '"]');
		
			/* Does the item exists? */
			if (item.length != 0)
			{
				/* Yes, change the value. */
				$(item).val (instance_config[key][i]);
				
					/* Is the item a select object? */
					if ($(item).is ('select'))
					{
						/* Yes, perform a change action on it. */
						$(item).change ();
					}
			}
	}
	
	/* Is there a 'ignore_servergroup' key in the instance config object, and is there a table present? */
	if ($('.table-servergroups').length > 0 && 'ignore_servergroup' in instance_config[key])
	{
		/* Yes, is it filled? */
		if (instance_config[key].ignore_servergroup.length > 0)
		{
			/* It is, loop through the array. */
			for (var i in instance_config[key].ignore_servergroup)
			{
				/* Define the sgid. */
				var sgid = instance_config[key].ignore_servergroup[i];
				
				/* Add the item to the table. */
				$('.table-servergroups > tbody:last-child').append ('<tr sgid="' + sgid + '"><td>' + sgid + '</td><td>' + server_groups[sgid] + '</td><td><a href="#" class="btn btn-danger btn-xs btn-servergroups-remove">Remove group</a></td></tr>');
			}
		}
		else
		{
			/* No, place a no-row message. */
			$('.table-servergroups tbody').append ('<tr><td colspan="3" class="text-center">Currently no servergroups are being excluded.</td></tr>');	
		}
	}
	
	/* Rehook events. */
	hook_events ();
}


/* Function that is used to take the settings on the page, and place it in instance_config object. */
function page_to_object_configuration (key)
{
	/* Loop through all input fields on the page. */
	$('input').each (function (index)
	{
		/* Does this configuration item exists? */
		if ($(this).attr ('name') in instance_config[key])
		{
			/* Yes, update it. */
			instance_config[key][$(this).attr ('name')] = $(this).val ();
		}
	});
	
	/* Loop through all select fields on the page. */
	$('select:not(.exclude)').each (function (index)
	{
		/* Does this configuration item exists? */
		if ($(this).attr ('name') in instance_config[key])
		{
			/* Yes, update it. */
			instance_config[key][$(this).attr ('name')] = $(this).val ();
		}
	});
	
	
	/* Is there a 'ignore_servergroup' key in the instance config object? */
	if ($('.table-servergroups').length > 0 && 'ignore_servergroup' in instance_config[key])
	{
		/* Yes, count the amount of rows in the tbody of the table. */
		var rows_amount = $('.table-servergroups tbody tr').length;
		
		/* Count the amount of no-rows rows. */
		var norows_amount = $('.table-servergroups tbody td[colspan="3"]').length;
		
		/* Empty the ignore_servergroup array. */
		instance_config[key]['ignore_servergroup'] = [];
		
			/* Are there any server groups set? */
			if ((rows_amount - norows_amount) > 0)
			{
				/* Yes, loop through rows. */
				$('.table-servergroups tbody tr').each (function (i)
				{
					/* Add the server group to the ignore_servergroup array. */
					instance_config[key]['ignore_servergroup'].push (parseInt ($(this).attr ('sgid')));
				});
			}
	}
}


/* Function that is executed upon clicking the save config button. */
function save_config (key)
{
	/* Disable the button. */
	$('.btn-save-configuration').prop ('disabled', true);
	
	/* Get the button text. */
	var button_text = $('.btn-save-configuration').text ();
	
	/* Change the button text, telling it we're currently saving the configuration. */
	$('.btn-save-configuration').text ('Saving...');
	
	/* Load the page configuration into the instance_config object. */
	page_to_object_configuration (key);
	
	/* Save the configuration. */
	set_instance_config (instance, (d) =>
	{
		/* Saving is completed. Rename the button back to its orginal text. */
		$('.btn-save-configuration').text (button_text);
		
		/* Enable the button. */
		$('.btn-save-configuration').prop ('disabled', false);
		
		/* Remove the hidden class on the success message. */
		$('.alert').show (250);
		
		/* Clear de saving_timeout timeout. */
		clearTimeout (saving_timeout);
		
		/* Create a timeout of 5 seconds. */
		saving_timeout = setTimeout (() =>
		{
			/* Add the hidden class again. */
			$('.alert').hide (250);
		}, 5000);
	});
}


/* When the DOM is ready. */
$(document).ready (function ()
{
	/* First, setup AJAX so we sent a authorization header with each AJAX request and that we're communicating with JSON data. */
	$.ajaxSetup ({
		headers: {
			'Authorization': 'bearer ' + window.localStorage.token,
			'Content-Type': 'application/json'
		},
		cache: false
	});
	
	/* When a menu item is clicked upon. */
	$('.navbar-nav li a').click (function (e)
	{
		/* Prevent default click behevior. */
		e.preventDefault ();
		
		/* Load the page. */
		load_page (this);
	});
	
	/* Load all instances. */
	load_all_instances ();
});