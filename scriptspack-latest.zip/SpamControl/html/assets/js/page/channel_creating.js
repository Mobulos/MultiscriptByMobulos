/* Channel creating object. */
var channel_creating = {
	
	/* Define the config key. */
	config_key: 'channel_creating',
	
	/* Function thats execute upon loading the page. */
	init: function ()
	{
		/* First, check if all configuration is present. If not, add the default values of each missing configuration item. */
		insert_configuration (this.config_key);
		
		/* Load the configuration into the page. */
		load_configuration (this.config_key);
		
		/* When the save config button is pressed, execute the save_config function. */
		$('.btn-save-configuration').click ((e) =>
		{
			/* Prevent default click behevior. */
			e.preventDefault ();
			
			/* Call the save_config function. */
			save_config (this.config_key);
		});
	}
};